    
    function validateForm(){
    var n = document.getElementById("nme").value;
    var e = document.getElementById("email").value;
    var p = document.getElementById("pass").value;
    var cp = document.getElementById("cpass").value;
    if(n.length<5){
        alert("*Length of name Support Minimum 5 Characters !");
        return false;
    }
    
    else if(n.length==0){
        alert("*Name is Mandatory");
        return false;
           }
   
       else if(e.length>20){
        alert("*Length of Email is 20 Characters Only !");
        return false;
    }
    
   
    
   
   else if(p.length<8){
    alert("*Password Should be 8 Character !");
    return false;
    }
    
   else if(cp.length<8){
        alert("*Confirm Password Should be 8 Character !");
        return false;
        }
    
   else if(p!=cp){
        alert("*Password and Confirm Password Not Match !");
        alert("*Password and Confirm Password Not Match !");
        return false;


    }else
    {
    return true;
    }
    }